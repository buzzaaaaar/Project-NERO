//=============================================================== Category ==============================================================================================
// const offcanvas = new bootstrap.Offcanvas(document.getElementById('offcanvasResponsive'));

// offcanvas._element.addEventListener('show.bs.offcanvas', function () {
//     // Add custom CSS styles for button layout when offcanvas is shown
//     document.getElementById('yourButtonId').classList.add('your-custom-class');
// });

// offcanvas._element.addEventListener('hidden.bs.offcanvas', function () {
//     // Remove custom CSS styles for button layout when offcanvas is hidden
//     document.getElementById('yourButtonId').classList.remove('your-custom-class');
// });

//==========================================================================================================================================================================


// function moveCategoryButtons() {
//     var categoryButtons = $('.category-buttons').html();
//     $('.filter-content').append(categoryButtons);
//   }
  
//   function restoreCategoryButtons() {
//     var categoryButtons = $('.filter-content .category-button').detach();
//     $('.category-buttons').html(categoryButtons);
//   }
  
//   function handleResize() {
//     if ($(window).width() < 768) {
//       moveCategoryButtons();
//     } else {
//       restoreCategoryButtons();
//     }
//   }
  
//   handleResize(); 
  
//   $(window).resize(function() {
//     handleResize();
//   });
  